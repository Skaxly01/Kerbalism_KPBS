This is simple. Place the executable somewhere in your path or put it directly in your KSP game folder along with the batch file.

Any time you add, update or muck around with parts, simply double click on the batch file, and all relevant KSP files will be sent to the recycle bin. 