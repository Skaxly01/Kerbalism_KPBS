Realism Extra Parts:
====================

KSP 1.1.3
Kerbalism 1.0.8

A small parts pack for Kerbalisms realism profile geared more toward 3 man crews and/or longer missions.

The following parts are clones or additions of parts already supplied with Kerbalism. All credit belongs to those who created and/or helped to create that mod. Except for the occasional re-texture of course.

1. Inline Water Tank - Stackable water tank for 21 days for a crew of 3.
2. Supply Container Plus - Stackable food and filter material for 21 days for a crew of 3.
3. Filtration Tank - Small radial surface attached tank with 16 days filtration material per kerbal. Non-Tweakable.

These parts were derived from the TAC Life support mod. All credit belongs to them. Models, texture files, and modified configs maintain TACLS identification.

1. Small LS container - Supports 2 kerbals for 15 days. Mass conserve by using half water and half filtration material.
2. Standard LS container - Supports 3 kerbals for 30 days. Mass conserve by using half water and half filtration material.
3. Large LS container - Supports 3 kerbals for 60 days. Mass conserve by using half water and half filtration material.
4. Large LS container Plus- Supports 3 kerbals for 90 days. Mass conserve by using half water and half filtration material. Adds entertainment with a packed movie and video game library.


As with any mod, simply copy over the Kerbalism directory into GameData. The parts are stored here: \GameData\Kerbalism\Parts\RealismExtra. Also recommend that 'PartsDatabase.cfg' and all Module Manager created files except the Dll be deleted.
