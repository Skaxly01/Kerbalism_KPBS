Currently just a few parts for Kerbalisms realism profile geared more toward 3 man crews and/or longer missions.


Large Inline Water Tank - Water tank for 15 days for a crew of 3.
Small Supply Container Plus - Food and filter material for 10 days for a crew of 3. 
Filtration Tank - 16 days filtration material per kerbal.

Others soon to be added.
 